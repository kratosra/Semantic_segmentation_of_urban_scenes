/***** spin: version.h *****/

/*
 * This file is part of the public release of Spin. It is subject to the
 * terms in the LICENSE file that is included in this source directory.
 * Tool documentation is available at http://spinroot.com
 */

#define SpinVersion	"Spin Version 6.5.1 -- 20 December 2019"
